module.exports = {
	head: {
		script: [
			// { src: "https://unpkg.com/xlsx/dist/xlsx.full.min.js" }, // CDN
			{ src: "xlsx.full.min.js" }, // development
			{ src: "https://unpkg.com/file-saver/FileSaver.js" }
		]
	}
};
